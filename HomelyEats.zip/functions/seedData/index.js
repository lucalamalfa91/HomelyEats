
const { getDb } = require("../shared/cosmosClient");
module.exports = async function (context, req) {
  const db = await getDb();
  const users = db.collection("users");
  const dishes = db.collection("dishes");

  await users.insertMany([
    { id: "chef1", name: "Luigi", rating: 4.8 },
    { id: "chef2", name: "Maria", rating: 4.2 }
  ]);

  await dishes.insertMany([
    { name: "Lasagne", price: 12, chef: "chef1" },
    { name: "Polpette", price: 10, chef: "chef2" }
  ]);

  context.res = {
    status: 200,
    body: "Seeding completato"
  };
};
